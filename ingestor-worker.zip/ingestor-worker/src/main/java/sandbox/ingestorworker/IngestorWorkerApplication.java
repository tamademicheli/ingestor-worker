package sandbox.ingestorworker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngestorWorkerApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngestorWorkerApplication.class, args);
	}
}
